# SAPA — paket aset pose animasi v1

Dibuat pada 2 Oktober 2026 menggunakan skill **imagegen**, melalui tool image generation bawaan.

Karakter mengikuti SAPA yang sudah ada: robot hijau, wajah ivory, dua daun di kepala, aksen cyan pada telinga, tangan pendek dan emblem daun pada dada.

## Isi paket

| Berkas | Isi | Urutan |
| --- | --- | --- |
| sapa-master.png | Pose dasar seluruh tubuh | Satu gambar |
| sapa-idle-blink-sheet.png | Diam, napas kecil, kedipan | 8 pose |
| sapa-wave-sheet.png | Menyapa dengan satu tangan | 8 pose |
| sapa-curious-sheet.png | Menoleh dan memperhatikan | 8 pose |
| sapa-thinking-sheet.png | Bekerja dengan tablet | 8 pose |
| sapa-success-jump-sheet.png | Bersiap, melompat, mendarat | 8 pose |
| sapa-helpful-error-sheet.png | Ekspresi prihatin lalu ramah | 8 pose |
| manifest.json | Ukuran gambar, koordinat sel, timing usulan dan anchor per pose | Data untuk integrasi berikutnya |
| prompts.json | Prompt final untuk setiap gambar terpilih | Reproduksi dan revisi |
| inspect_assets.py | Membaca metadata dan menghitung anchor; tidak mengubah gambar | Utilitas analisis aset |

Total: satu master dan enam sprite sheet, berisi **48 pose**.

Seluruh PNG terpilih memiliki kanal alpha/transparansi. Aset lama pada aplikasi tidak ditimpa.

## Cara membaca sprite sheet

Setiap sheet berisi **4 kolom × 2 baris**:

1. Baris atas: frame 0, 1, 2, 3.
2. Baris bawah: frame 4, 5, 6, 7.

Gunakan ukuran aktual pada manifest. Output gambar berukuran 1774 × 887 piksel, sehingga sel matematisnya 443,5 × 443,5 piksel. Jangan menganggap selnya 256 atau 512 piksel; koordinat sumber dalam manifest menggunakan nilai pecahan agar batas sel tetap konsisten.

## Status dan penggunaan

Ini paket **gambar pose**, bukan file animasi yang sudah diputar atau perubahan web. Timing pada manifest adalah titik awal usulan. Perpindahan pose, pemicu interaksi, dan sinkronisasi request AI belum dipasang ke aplikasi.

Hasil generasi memiliki sedikit variasi pusat tubuh dan baseline antarpose. Manifest mencantumkan anchor kaki yang dihitung dari gambar dan saran offset untuk membantu registrasi saat integrasi. Periksa hasil pada ukuran tampilan 65/59 piksel dan rapikan perpindahannya sebelum mengaktifkan animasi di web.

Anchor merupakan perkiraan dari piksel hijau yang cukup opak pada bagian bawah tubuh, bukan data rig asli. Pada animasi melompat, perpindahan vertikal disengaja; gunakan tinggi terbang yang ditentukan dalam manifest agar registrasi tidak menghapus lompatan.

Tetap gunakan kanvas tetap dengan ruang kosong di sekitar tubuh. Jangan memotong setiap pose berdasarkan siluetnya sendiri lalu memusatkan ulang, karena tinggi lompatan dan gerakan kepala dapat hilang.

## Timing awal

- **Idle:** siklus 8 detik, sebagian besar menahan pose; kedipan sekitar 170 ms. Jangan memutar delapan pose dengan durasi sama.
- **Menyapa:** sekitar 800 ms, sekali ketika panel dibuka.
- **Penasaran:** sekitar 800 ms, sekali saat hover/fokus; beri jeda sebelum mengulang.
- **Berpikir:** siklus 1,6 detik, berulang selama request AI masih berjalan.
- **Berhasil:** sekitar 640 ms, satu lompatan ketika hasil sukses diterima.
- **Gagal:** sekitar 900 ms, sekali setelah kegagalan request; tampilkan pesan error yang jelas di UI.

Keadaan berpikir/berhasil/gagal mengikuti request nyata. Tidak membutuhkan API per frame. Area klik dan drag tetap stabil.

## Prompt dan sumber

Prompt lengkap ada di prompts.json. Referensi sumber adalah dua gambar SAPA yang sudah tersimpan di proyek. Paket final dipilih setelah inspeksi bentuk, arah tangan dan keberadaan alpha; alternatif yang tidak dipilih tidak disertakan.

Belum ada implementasi, commit, atau push yang dilakukan untuk paket ini.
